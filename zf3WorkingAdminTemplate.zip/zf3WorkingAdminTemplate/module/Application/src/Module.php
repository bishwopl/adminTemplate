<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application;

use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\ModuleManager\Feature\ServiceProviderInterface;

class Module
{
    const VERSION = '3.0.2dev';

    public function onBootstrap(MvcEvent $e) {
        $eventManager = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);

        $sm = $e->getApplication()->getServiceManager();

        // This will inject the properly-configured SessionManager instance as the default for all new session containers
        $manager = $e->getApplication()->getServiceManager()->get('Zend\Session\ManagerInterface');

        // Add ACL information to the Navigation view helper
        $authorize = $sm->get(\BjyAuthorize\Service\Authorize::class);
        $acl = $authorize->getAcl();
        $role = $authorize->getIdentity();
        \Zend\View\Helper\Navigation::setDefaultAcl($acl);
        \Zend\View\Helper\Navigation::setDefaultRole($role);

        
        //For layout according to user role START
        $config = $e->getApplication()->getServiceManager()->get('config');
        if (isset($config['role_wise_layouts'])) {
            
            $e->getApplication()->getEventManager()->getSharedManager()
                ->attach('Zend\Mvc\Application', 'dispatch', function($e) {
                    $roles = $this->getUserRoles($e);
                    if ($roles === false) {
                        return;
                    }
                    $config = $e->getApplication()->getServiceManager()->get('config');
                    if (isset($config['role_wise_layouts'])) {
                        $key = $this->getMatchedeElement(array_keys($config['role_wise_layouts']), $roles);
                        if ($key !== false) {
                            $e->getViewModel()->setTemplate($config['role_wise_layouts'][$key]);
                        }
                    }
            }, 100);
            $e->getApplication()->getEventManager()->getSharedManager()
                ->attach('Zend\Mvc\Application', 'dispatch.error', function($e) {
                    $roles = $this->getUserRoles($e);
                    if ($roles === false) {
                        return;
                    }
                    $config = $e->getApplication()->getServiceManager()->get('config');
                    if (isset($config['role_wise_layouts'])) {
                        $key = $this->getMatchedeElement(array_keys($config['role_wise_layouts']), $roles);
                        if ($key !== false) {
                            $e->getViewModel()->setTemplate($config['role_wise_layouts'][$key]);
                        }
                    }
            }, 100);
        }
        return;
        //For layout according to user role END
    }

    public function getServiceConfig() {
        return [
            'factories' => [
                // Configures the default SessionManager instance
                'Zend\Session\ManagerInterface' => 'Zend\Session\Service\SessionManagerFactory',
                // Provides session configuration to SessionManagerFactory
                
                //'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
                'Navigation' => 'Zend\Navigation\Service\DefaultNavigationFactory',
                
                'Zend\Session\Config\ConfigInterface' => 'Zend\Session\Service\SessionConfigFactory',
                'Application\Service\IndexService' => 'Application\Factory\Service\IndexServiceFactory',
            ],
            'abstract_factories' => [
                'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
                'Zend\Log\LoggerAbstractServiceFactory',
            ],
            'aliases' => [
                'translator' => 'MvcTranslator',
            ],
        ];
    }

    public function getControllerConfig() {
        return [
            'factories' => [
                'Application\Controller\Index' => 'Application\Factory\Controller\IndexControllerFactory',
            ],
        ];
    }

    public function getViewHelperConfig() {
        return [
            'factories' => [
                'showSiteIdentity' => function($e) {
                    return new \Application\View\Helper\ShowSiteIdentity($e->getServiceLocator()->get('Config'));
                },
                'currentRoute' => function($e) {
                    $routeMatch = $e->getServiceLocator()->get('Application')->getMvcEvent()->getRouteMatch();
                    $controller = $action = $route = $module = '';
                    if ($routeMatch) {
                        $controller = $routeMatch->getParam('controller');
                        $action = $routeMatch->getParam('action');
                        $module = $routeMatch->getParam('__NAMESPACE__');
                        $route = $routeMatch->getMatchedRouteName();
                    }
                    return new \Application\View\Helper\CurrentRoute($controller, $action, $route, $module);
                }
            ],
        ];
    }

    public function getConfig() {
        return include __DIR__ . '/../config/module.config.php';
    }

    public function getAutoloaderConfig() {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    function getMatchedeElement($arr1, $arr2) {
        foreach ($arr1 as $a) {
            if (in_array($a, $arr2)) {
                return $a;
            }
        }
        return false;
    }

    protected function getUserRoles(MvcEvent $e) {
        $authorize = $e->getApplication()->getServiceManager()->get('BjyAuthorize\Provider\Identity\ProviderInterface');
        $roleObjects = $authorize->getIdentityRoles();
        $roles = array();
        foreach ($roleObjects as $r) {
            if (!is_object($r)) {
                return false;
            }
            do {
                $roles[] = $r->getRoleid();
                $r = $r->getParent();
            } while ($r !== NULL && ($r->getParent() !== NULL));
        }
        //var_dump($roles);
        return $roles;
    }

}
