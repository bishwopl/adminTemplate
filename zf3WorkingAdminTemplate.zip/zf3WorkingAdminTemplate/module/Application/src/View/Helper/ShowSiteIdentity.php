<?php

/**
 * 
 * @author Bishwo Prasad Lamichhane <bishwo.prasad@gmail.com>
 */

namespace Application\View\Helper;
use Zend\View\Helper\AbstractHelper;

class ShowSiteIdentity extends AbstractHelper
{
    protected $config;

    public function __construct($config) {
        $this->config = $config;
    }

    /**
     * 
     * @param string $type
     * @return string
     */
    public function __invoke($type)
    {
        if(isset($this->config[$type])){
            return $this->config[$type];
        }
        return '';
    }
}