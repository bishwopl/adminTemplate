<?php

namespace MyUser\Controller;

use Zend\Stdlib\ResponseInterface as Response;
use Zend\Stdlib\Parameters;
use Zend\View\Model\ViewModel;
use Zend\Mail;
use Zend\Math\Rand;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
use Zend\Session\Container;

class MyUserController extends \ZfcUser\Controller\UserController
{
    protected $em;
    
    public function getEntityManager()
    {
        if (null === $this->em) {
            $this->em = $this->serviceLocator
                ->get('doctrine.entitymanager.orm_default');
        }
        return $this->em;
    }
    
    /**
     * Register new user
     */
    public function registerAction()
    {
        // if the user is logged in, we don't need to register
        if ($this->zfcUserAuthentication()->hasIdentity()) {
            // redirect to the login redirect route
            return $this->redirect()->toRoute($this->getOptions()->getLoginRedirectRoute());
        }
        // if registration is disabled
        if (!$this->getOptions()->getEnableRegistration()) {
            return array('enableRegistration' => false);
        }

        $request = $this->getRequest();
        $service = $this->getUserService();
        $form = $this->getRegisterForm();

        if ($this->getOptions()->getUseRedirectParameterIfPresent() && $request->getQuery()->get('redirect')) {
            $redirect = $request->getQuery()->get('redirect');
        } else {
            $redirect = false;
        }

        $redirectUrl = $this->url()->fromRoute(static::ROUTE_REGISTER)
            . ($redirect ? '?redirect=' . rawurlencode($redirect) : '');
        $prg = $this->prg($redirectUrl, true);

        if ($prg instanceof Response) {
            return $prg;
        } elseif ($prg === false) {
            return array(
                'registerForm' => $form,
                'enableRegistration' => $this->getOptions()->getEnableRegistration(),
                'redirect' => $redirect,
            );
        }

        $post = $prg;
        $user = $service->register($post);

        $redirect = isset($prg['redirect']) ? $prg['redirect'] : null;

        if (!$user) {
            return array(
                'registerForm' => $form,
                'enableRegistration' => $this->getOptions()->getEnableRegistration(),
                'redirect' => $redirect,
            );
        }

        if ($service->getOptions()->getLoginAfterRegistration()) {
            $identityFields = $service->getOptions()->getAuthIdentityFields();
            if (in_array('email', $identityFields)) {
                $post['identity'] = $user->getEmail();
            } elseif (in_array('username', $identityFields)) {
                $post['identity'] = $user->getUsername();
            }
            $post['credential'] = $post['password'];
            $request->setPost(new Parameters($post));
            return $this->forward()->dispatch(static::CONTROLLER_NAME, array('action' => 'authenticate'));
        }
        // TODO: Add the redirect parameter here...
        $this->sendActivationMail($user);
        return $this->redirect()->toRoute('zfcuser/registrationsuccess');
    }
    
    protected function sendActivationMail($user){
        $activationToken = "A".Rand::getString(32, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', true);
        
        $activation = new \MyUser\Entity\Activation();
        $activation->setUser($user);
        $activation->setActivationToken($activationToken);
        $this->getEntityManager()->persist($activation);
        $this->getEntityManager()->flush();
        
        $link = "http://mydomain/user/activate/".  urlencode($activationToken);
        $htmlMarkup = "Please copy the following link and paste in address bar "
                . "of your internet browser to activate your account. "
                . "<a href=\"".$link."\">".$link."</a>";
        $html = new MimePart($htmlMarkup);
        $html->type = "text/html";
        
        $body = new MimeMessage();
        $body->setParts(array($html));
        
        $mail = new Mail\Message();
		
        $mail->setBody($body)
             ->setFrom('myemail@com.com', 'My Application')
             ->addTo($user->getEmail(), '')
             ->setSubject('Account Activation');
        $transport = new Mail\Transport\Sendmail();
        $transport->send($mail);
    }
     
    public function activateAction() 
    {
        if ($this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute($this->getOptions()->getLoginRedirectRoute());
        }
        $activation_string = urldecode($this->params()->fromRoute('activation_string', 0));
        if($activation_string==''){
            return $this->redirect()->toRoute('home');
        }
        $result = $this->getEntityManager()->getRepository("\MyUser\Entity\Activation")->createQueryBuilder('o')
        ->where('o.activationToken = :activationToken')
        ->setParameter('activationToken', $activation_string)
        ->getQuery()->getResult();
        $activation = $result[0];
        
        if($activation){
            $user = $activation->getUser();
            $user->setState(1);
            
            $applicantUserRole = $this->em->getRepository('MyUser\Entity\Role')->findOneByRoleId('applicant');
            $user->addRole($applicantUserRole);
            
            $this->em->persist($user);
            $this->em->remove($activation);
            $this->em->flush();
        }
        else{
            return $this->redirect()->toRoute($this->getOptions()->getLoginRedirectRoute());
        }
    }
    
    public function registrationsuccessAction() {
        if ($this->zfcUserAuthentication()->hasIdentity()) {
            // redirect to the login redirect route
            return $this->redirect()->toRoute($this->getOptions()->getLoginRedirectRoute());
        }
        return new ViewModel();
    }
    
    public function forgotpasswordAction() {
        if ($this->zfcUserAuthentication()->hasIdentity()) {
            // redirect to the login redirect route
            return $this->redirect()->toRoute($this->getOptions()->getLoginRedirectRoute());
        }
        
        $forgotPasswordForm = new \MyUser\Form\ForgotPasswordForm();
        $data = $this->getRequest()->getPost()->toArray();
        $forgotPasswordForm->setData($data);
        
        $vm = new ViewModel();
        if ($this->getRequest()->isPost() && $forgotPasswordForm->isValid()) {
            $email = $data['email'];
            $user = $this->getUserService()->getUserMapper()->findByEmail($email);
            if(is_object($user)){
                $this->sendActivationMail($user);
            }
            $vm->setVariable('email', $email);
            $vm->setTemplate("my-user/sent");
        }
        
        
        $vm->setVariable('forgotForm', $forgotPasswordForm);
        return $vm;
    }
    
    public function logoutAction() {
        $this->zfcUserAuthentication()->getAuthAdapter()->resetAdapters();
        $this->zfcUserAuthentication()->getAuthAdapter()->logoutAdapters();
        $this->zfcUserAuthentication()->getAuthService()->clearIdentity();
        
        $redirect = $this->redirectCallback;
        session_unset();
        session_destroy();
        return $redirect();
    }
    
    public function authenticateAction() {
        if ($this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute($this->getOptions()->getLoginRedirectRoute());
        }

        $adapter = $this->zfcUserAuthentication()->getAuthAdapter();
        $redirect = $this->params()->fromPost('redirect', $this->params()->fromQuery('redirect', false));

        $result = $adapter->prepareForAuthentication($this->getRequest());

        // Return early if an adapter returned a response
        if ($result instanceof Response) {
            return $result;
        }

        $auth = $this->zfcUserAuthentication()->getAuthService()->authenticate($adapter);

        if (!$auth->isValid()) {
            $this->flashMessenger()->setNamespace('zfcuser-login-form')->addMessage($this->failedLoginMessage);
            $adapter->resetAdapters();
            return $this->redirect()->toUrl(
                $this->url()->fromRoute(static::ROUTE_LOGIN) .
                ($redirect ? '?redirect='. rawurlencode($redirect) : '')
            );
        }
        
        //added start
        $authorize = $this->serviceLocator->get('BjyAuthorize\Provider\Identity\ProviderInterface');
        $roleObjects = $authorize->getIdentityRoles();
        $roles = [];
        $rolesHigher = [];
        foreach($roleObjects as $r){
            if(!is_object($r)) { return false; }
            $rolesHigher[] = $r->getRoleid();
            do{
                if(!in_array($r->getRoleid(), $roles)){
                    $roles[] = $r->getRoleid();
                }
                $r = $r->getParent();
            }while($r!==NULL && ($r->getParent()!==NULL));
        }
        $rolesContainer = new \Zend\Session\Container('UsersRoles');
        $key = 'roles';
        $keyHigher = 'rolesHigher';
        $rolesContainer->$key = $roles;
        $rolesContainer->$keyHigher = $rolesHigher;
        //added end
        
        $redirect = $this->redirectCallback;

        return $redirect();
    }
}
