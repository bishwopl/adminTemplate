<?php

/**
 * 
 * @author Bishwo Prasad Lamichhane <bishwo.prasad@gmail.com>
 */

namespace MyUser\Form;

use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilterProviderInterface;

class ForgotPasswordForm extends Form implements InputFilterProviderInterface{
    public function __construct()
    {
        parent::__construct('forgot-password-form');
        
        $this->setAttribute('enctype', 'multipart/form-data');
        $this->setAttribute('METHOD', 'POST');
        $this->setAttribute('class', 'form-horizontal');
        
        $this->add([
            'name' => 'email',
            'options' => [
                'label' => 'Your Email Address',
            ],
            'attributes' => [
                'type' => 'text',
                'required' => 'true'
            ],
        ]);
        
        $submitElement = new Element\Button('submit');
        $submitElement
            ->setLabel('Request new password')
            ->setAttributes([
                'type'  => 'submit',
                'class' => 'btn btn-success'
            ]);
        $this->add($submitElement);
    }
    public function getInputFilterSpecification() {
        return [
            "email" => [
                "required" => true,
                "filters" => [],
                "validators" => [
                    [
                        "name" => \Zend\Validator\EmailAddress::class
                    ]
                ],
            ],
        ];
    }
}