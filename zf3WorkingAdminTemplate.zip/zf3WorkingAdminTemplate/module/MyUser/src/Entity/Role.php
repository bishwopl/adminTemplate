<?php

namespace MyUser\Entity;

use Doctrine\ORM\Mapping as ORM;
use BjyAuthorize\Acl\HierarchicalRoleInterface;

/**
 * Role
 *
 * @ORM\Table(name="role", uniqueConstraints={@ORM\UniqueConstraint(name="UNIQ_57698A6AB8C2FD88", columns={"roleId"})}, indexes={@ORM\Index(name="IDX_57698A6A727ACA70", columns={"parent_id"})})
 * @ORM\Entity
 */
class Role implements HierarchicalRoleInterface
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", precision=0, scale=0, nullable=false, unique=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="roleId", type="string", length=255, precision=0, scale=0, nullable=true, unique=false)
     */
    private $roleId;

    /**
     * @var \MyUser\Entity\Role
     *
     * @ORM\ManyToOne(targetEntity="MyUser\Entity\Role")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id", nullable=true)
     * })
     */
    private $parent;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="MyUser\Entity\Users", mappedBy="role")
     */
    private $user;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->user = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set roleId
     *
     * @param string $roleId
     *
     * @return Role
     */
    public function setRoleid($roleId)
    {
        $this->roleId = $roleId;

        return $this;
    }

    /**
     * Get roleId
     *
     * @return string
     */
    public function getRoleid()
    {
        return $this->roleId;
    }

    /**
     * Set parent
     *
     * @param \MyUser\Entity\Role $parent
     *
     * @return Role
     */
    public function setParent(\MyUser\Entity\Role $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \MyUser\Entity\Role
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Add user
     *
     * @param \MyUser\Entity\Users $user
     *
     * @return Role
     */
    public function addUser(\MyUser\Entity\Users $user)
    {
        $this->user[] = $user;

        return $this;
    }

    /**
     * Remove user
     *
     * @param \MyUser\Entity\Users $user
     */
    public function removeUser(\MyUser\Entity\Users $user)
    {
        $this->user->removeElement($user);
    }

    /**
     * Get user
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUser()
    {
        return $this->user;
    }
}
