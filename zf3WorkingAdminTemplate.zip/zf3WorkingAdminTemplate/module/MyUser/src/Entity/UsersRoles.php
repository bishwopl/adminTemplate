<?php

namespace MyUser\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UsersRoles
 *
 * @ORM\Table(name="users_roles", uniqueConstraints={@ORM\UniqueConstraint(name="user_id", columns={"user_id", "role_id"})}, indexes={@ORM\Index(name="FK_51498A8ED60322AC", columns={"role_id"}), @ORM\Index(name="IDX_51498A8EA76ED395", columns={"user_id"})})
 * @ORM\Entity
 */
class UsersRoles
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \MyUser\Entity\Users
     *
     * @ORM\ManyToOne(targetEntity="MyUser\Entity\Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     * })
     */
    private $user;

    /**
     * @var \MyUser\Entity\Role
     *
     * @ORM\ManyToOne(targetEntity="MyUser\Entity\Role")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="role_id", referencedColumnName="id")
     * })
     */
    private $role;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set user
     *
     * @param \MyUser\Entity\Users $user
     *
     * @return UsersRoles
     */
    public function setUser(\MyUser\Entity\Users $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \MyUser\Entity\Users
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set role
     *
     * @param \MyUser\Entity\Role $role
     *
     * @return UsersRoles
     */
    public function setRole(\MyUser\Entity\Role $role = null)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return \MyUser\Entity\Role
     */
    public function getRole()
    {
        return $this->role;
    }
}
