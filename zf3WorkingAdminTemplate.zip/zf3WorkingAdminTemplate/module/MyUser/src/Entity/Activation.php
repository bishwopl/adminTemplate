<?php

namespace MyUser\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Activation
 *
 * @ORM\Table(name="activation", indexes={@ORM\Index(name="FK_activation", columns={"user_id"})})
 * @ORM\Entity
 */
class Activation
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint", precision=0, scale=0, nullable=false, unique=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="activation_token", type="string", length=255, precision=0, scale=0, nullable=false, unique=false)
     */
    private $activationToken;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="token_created", type="datetime", precision=0, scale=0, nullable=false, unique=false)
     */
    private $tokenCreated;

    /**
     * @var \MyUser\Entity\Users
     *
     * @ORM\ManyToOne(targetEntity="MyUser\Entity\Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="user_id", referencedColumnName="id", nullable=true)
     * })
     */
    private $user;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set activationToken
     *
     * @param string $activationToken
     *
     * @return Activation
     */
    public function setActivationToken($activationToken)
    {
        $this->activationToken = $activationToken;

        return $this;
    }

    /**
     * Get activationToken
     *
     * @return string
     */
    public function getActivationToken()
    {
        return $this->activationToken;
    }

    /**
     * Set tokenCreated
     *
     * @param \DateTime $tokenCreated
     *
     * @return Activation
     */
    public function setTokenCreated($tokenCreated)
    {
        $this->tokenCreated = $tokenCreated;

        return $this;
    }

    /**
     * Get tokenCreated
     *
     * @return \DateTime
     */
    public function getTokenCreated()
    {
        return $this->tokenCreated;
    }

    /**
     * Set user
     *
     * @param \MyUser\Entity\Users $user
     *
     * @return Activation
     */
    public function setUser(\MyUser\Entity\Users $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \MyUser\Entity\Users
     */
    public function getUser()
    {
        return $this->user;
    }
}

