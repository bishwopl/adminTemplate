<?php

namespace MyUser\Options;

class ModuleOptions extends \ZfcUser\Options\ModuleOptions {

}
