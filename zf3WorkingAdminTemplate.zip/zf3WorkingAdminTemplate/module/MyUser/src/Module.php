<?php

namespace MyUser;

use Zend\Mvc\MvcEvent;
use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\ModuleManager\Feature\ServiceProviderInterface;

class Module implements AutoloaderProviderInterface, ConfigProviderInterface, ServiceProviderInterface {

    public function getAutoloaderConfig() {
        return [
            'Zend\Loader\StandardAutoloader' => [
                'namespaces' => [
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ],
            ],
        ];
    }

    public function getServiceConfig() {
        return [
        ];
    }

    public function getControllerConfig() {
        return [
            'factories' => [
                'zfcuser' => function($serviceManager) {
                    /* @var RedirectCallback $redirectCallback */
                    $redirectCallback = $serviceManager->get('zfcuser_redirect_callback');

                    /* @var UserController $controller */
                    $controller = new \MyUser\Controller\MyUserController($redirectCallback);
                    $controller->setServiceLocator($serviceManager);

                    $controller->setChangeEmailForm($serviceManager->get('zfcuser_change_email_form'));
                    $controller->setOptions($serviceManager->get('zfcuser_module_options'));
                    $controller->setChangePasswordForm($serviceManager->get('zfcuser_change_password_form'));
                    $controller->setLoginForm($serviceManager->get('zfcuser_login_form'));
                    $controller->setRegisterForm($serviceManager->get('zfcuser_register_form'));
                    $controller->setUserService($serviceManager->get('zfcuser_user_service'));

                    return $controller;
                },
                \MyUser\Controller\MyUserController::class => \ZfcUser\Factory\Controller\UserControllerFactory::class,
            ],
        ];
    }

    public function getConfig() {
        return include __DIR__ . '/../config/module.config.php';
    }

    public function onBootstrap(MvcEvent $e) {
        $sm = $e->getApplication()->getServiceManager();

        $router = $sm->get('router');
        $request = $sm->get('request');
        $matchedRoute = $router->match($request);
        if (is_object($e->getRequest()) && method_exists($e->getRequest(), getBaseUrl)) {
            $baseUrl = $e->getRequest()->getBaseUrl();
        }
        if ($matchedRoute !== NULL) {

            $params = $matchedRoute->getParams();

            $controller = $params['controller'];
            $action = $params['action'];

            $module_array = explode('\\', $controller);
            $module = array_pop($module_array);

            $route = $matchedRoute->getMatchedRouteName();
            if ($module == 'zfcuser' || $module == __NAMESPACE__ || $module == 'goalioforgotpassword_forgot') {
                $sm = $e->getApplication()->getServiceManager();
                $headScript = $sm->get('ViewHelperManager')->get('headScript');
                $headScript->appendFile($baseUrl . '/js/form_formatter.js');
            }
        }

        if ($this->checkAutoLogout($sm) == true) {
            session_unset();
            session_destroy();
        }
    }

    //for auto logout start
    protected function checkAutoLogout($sm) {
        $rolesContainer = new \Zend\Session\Container('UsersRoles');
        $key = 'roles';

        //check if user is logged in
        if (is_array($rolesContainer->$key) &&
                sizeof($rolesContainer->$key) > 0 &&
                !in_array('guest', $rolesContainer->$key)) {
            
            $config = $sm->get('Config');
            $userConfig = $config['zfcuser'];
            $autoLogoutPeriod = $userConfig['auto_logout_period'];
            $lastActivityContainer = new \Zend\Session\Container('lastActivityContainer');
            $lastActivityKey = 'lastActivityTimestamp';

            if ($lastActivityContainer->$lastActivityKey == NULL) {
                //Set current activitytime for the first time;
                $lastActivityContainer->$lastActivityKey = time();
            } 
            
            $lastActivityTime = $lastActivityContainer->$lastActivityKey;
            
            if ((time() - $lastActivityTime) > $autoLogoutPeriod) {
                //Time finished so force logout the user
                return true;
            } else {
                //Update current activitytime;
                $lastActivityContainer->$lastActivityKey = time();
            }
        } else {
            //User is not logged in 
        }
        return false;
    }

}
