<?php

namespace MyUser;

use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;

$env = getenv('APP_ENV') ?: 'production';

return [
    'doctrine' => [
        'driver' => [
            // overriding zfc-user-doctrine-orm's config
            'zfcuser_entity' => [
                'class' => 'Doctrine\ORM\Mapping\Driver\AnnotationDriver',
                'paths' => __DIR__ . '/../src/Entity',
            ],
            'orm_default' => [
                'drivers' => [
                    'MyUser\Entity' => 'zfcuser_entity',
                ],
            ],
        ],
    ],
    'default-roles' => [
        'applicant'
    ],
    'editable-roles' => [
        'applicant',
    ],
    'zfcuser' => [
        // telling ZfcUser to use our own class
        'user_entity_class' => 'MyUser\Entity\Users',
        // telling ZfcUserDoctrineORM to skip the entities it defines
        'enable_default_entities' => false,
    ],
    'bjyauthorize' => [
        'guards' => [
            'BjyAuthorize\Guard\Controller' => [
                ['controller' => 'zfcuser', 'roles' => ['guest', 'user'],],
                ['controller' => 'goalioforgotpassword_forgot', 'roles' => ['guest'],],
            ],
            'BjyAuthorize\Guard\Route' => [
                ['route' => 'zfcuser', 'roles' => ['user', 'guest'],],
                ['route' => 'zfcuser/changepassword', 'roles' => ['user'],],
                //['route' => 'zfcuser/changeemail',  'roles' => ['user'],],
                ['route' => 'zfcuser/logout', 'roles' => ['guest', 'user'],],
                ['route' => 'zfcuser/login', 'roles' => ['guest', 'user'],],
                ['route' => 'zfcuser/registrationsuccess', 'roles' => ['guest'],],
                ['route' => 'zfcuser/activate', 'roles' => ['guest'],],
                ['route' => 'zfcuser/register', 'roles' => ['guest'],],
                ['route' => 'zfcuser/forgotpassword', 'roles' => ['guest'],],
                ['route' => 'zfcuser/resetpassword', 'roles' => ['guest'],],
            ],
        ],
        'rule_providers' => [
            'BjyAuthorize\Provider\Rule\Config' => [
                'allow' => [
                    [['user'], 'user_info', ['list', 'add', 'edit', 'delete'],],
                ],
            ],
        ],
        'resource_providers' => [
            'BjyAuthorize\Provider\Resource\Config' => [
                'user_info' => [],
            ],
        ],
    ],
    'router' => [
        'routes' => [
            'zfcuser' => [
                'child_routes' => [
                    'registrationsuccess' => [
                        'type' => Literal::class,
                        'options' => [
                            'route' => '/registrationsuccess',
                            'defaults' => [
                                'controller' => 'zfcuser',
                                'action' => 'registrationsuccess',
                            ],
                        ],
                    ],
                    'activate' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/activate/[:activation_string]',
                            'constraints' => [
                                'activation_string' => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ],
                            'defaults' => [
                                'controller' => 'zfcuser',
                                'action' => 'activate',
                            ],
                        ],
                    ],
                    'forgotpassword' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/forgotpassword',
                            'constraints' => [
                                'activation_string' => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ],
                            'defaults' => [
                                'controller' => 'zfcuser',
                                'action' => 'forgotpassword',
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
    'view_manager' => [
        'template_path_stack' => [
            'zfcuser' => __DIR__ . '/../view',
            'goalioforgotpassword' => __DIR__ . '/../view',
        ],
        'template_map' => [
            'my-user/email-sent' => __DIR__ . '/../view/my-user/my-user/sent.phtml',
        ]
    ],
    'navigation' => [
        'default' => [
            'user_info' => [
                'label' => 'My Account',
                'route' => 'zfcuser',
                'icon' => 'fa fa-user-circle',
                'resource' => 'user_info',
                'privilege' => 'list',
                'order' => 10000,
                'pages' => [
                    /* 'account_home' => [
                      'label' => 'My Account',
                      'route' => 'zfcuser',
                      'icon'=>'fa fa-user',
                      'resource' => 'user_info',
                      'privilege' => 'list',
                      ],
                      'change_email' => [
                      'label' => 'Change Email',
                      'route' => 'zfcuser/changeemail',
                      'icon'=>'fa fa-edit',
                      'resource' => 'user_info',
                      'privilege' => 'edit',
                      ], */
                    'change_password' => [
                        'label' => 'Reset Password',
                        'route' => 'zfcuser/changepassword',
                        'icon' => 'fa fa-repeat',
                        'resource' => 'user_info',
                        'privilege' => 'edit',
                    ],
                    'logout' => [
                        'label' => 'Logout',
                        'route' => 'zfcuser/logout',
                        'icon' => 'fa fa-arrow-right',
                        'resource' => 'user_info',
                        'privilege' => 'list',
                    ],
                ],
            ],
        ],
    ],
];
