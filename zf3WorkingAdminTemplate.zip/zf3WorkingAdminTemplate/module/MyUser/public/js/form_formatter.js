jQuery(function($) {
    $('input[type=text], input[type=password]').addClass("form-control input");
    if($(":submit").hasClass('btn')===false){
       $(":submit").addClass("form-control btn btn-success");
       $(":submit").css("margin-top","20px");
    }
});
