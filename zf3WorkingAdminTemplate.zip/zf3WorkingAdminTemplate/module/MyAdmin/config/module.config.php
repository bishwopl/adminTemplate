<?php
return [
    'view_manager' => [
        'template_path_stack' => [
            'myadmin' => __DIR__ . '/../view',
        ],
    ],
    'router' => [
        'routes' => [
            
        ],
    ],
    
    'bjyauthorize' => [
        'guards' => [
            'BjyAuthorize\Guard\Controller' => [
                ['controller' => 'ZfcAdmin\Controller\AdminController', 'roles' => ['administrator'],],
            ],
            'BjyAuthorize\Guard\Route' => [
                ['route' => 'zfcadmin',  'roles' => ['administrator'],],
            ],
        ],
        'rule_providers' => [
            'BjyAuthorize\Provider\Rule\Config' => [
                'allow' => [
                    [['administrator'],'user_control',['list','add','edit','delete'],],
                ],
            ],
        ],
        'resource_providers' => [
            'BjyAuthorize\Provider\Resource\Config' => [
                'user_control' => [],
            ],
        ],
    ],
    
    'navigation' => [
        'default' => [
            
        ],
    ],
];