$(document).ready(function () {
    $('.selectpicker').selectpicker({
        style: 'btn-default btn-sm',
        size: 6
    });
    $('[data-toggle="tooltip"]').tooltip({html: true});
    $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '10%' // optional
    });
});
