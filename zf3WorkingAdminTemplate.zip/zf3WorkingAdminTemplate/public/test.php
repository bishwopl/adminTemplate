<?php
$filename = "D:\\websites\\tuservice\\test.txt";
if (file_exists($filename)) {
    $content = file_get_contents($filename);
    $array = unserialize($content);
    var_dump($array);
} else {
    echo "file not exists";
}

