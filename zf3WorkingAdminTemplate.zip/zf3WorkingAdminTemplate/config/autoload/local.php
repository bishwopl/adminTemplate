<?php

/**
 * 
 * @author Bishwo Prasad Lamichhane <bishwo.prasad@gmail.com>
 */
return [
    'site_title' => 'My Application',
    'guest_page_header' => 'My Application',
    'admin_page_header' => 'My Admin',
    'admin_page_header_small' => 'MA',
    'site_footer' => 'My footer'
];
