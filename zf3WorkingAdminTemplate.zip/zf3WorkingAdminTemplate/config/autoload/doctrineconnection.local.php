<?php
/**
 * This file will only be needed if you didn't set up a Doctrine-Connection yet
 */
return [
    'doctrine' => [
        'connection' => [
            'orm_default' => [
                'driverClass' => 'Doctrine\DBAL\Driver\PDOMySql\Driver',
                'params'      => [
                    'host'     => 'localhost',
                    'port'     => '3306',
                    'user'     => 'root',
                    'password' => 'root',
                    'dbname'   => 'root',
                    'driverOptions' => [
                        1002 => 'SET NAMES utf8mb4'
                    ],
                ],
            ],
        ],
    ],
];